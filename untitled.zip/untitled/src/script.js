const registro = prompt('Bom dia senhor, por favor me informe seu registro')
if (registro == '1026') {
  console.log('Acesso autorizado, pode esperar o atendimento.')}
else {
  console.log('Acesso negado, seu registro não foi encontrado.')
};

const Navegador = prompt('Por qual físico você deseja aprender?');
const nomes = ['Einstein', 'Newton', 'Oppenheimer'];

if (nomes.includes(Navegador)) {
    console.log('Ótima escolha!');
} else {
    console.log('Esse físico não foi encontrado no nosso banco de dados.');
}


